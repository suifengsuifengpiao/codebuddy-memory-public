# legado-booksource-debug v1.15.25 · 发布说明（勘误版）

对应技能 `legado-booksource-debug` v1.15.25（`SKILL.md` frontmatter / `_meta.json` version / `_meta.json` display_name / `check_request_layer.py` docstring 四处同步）。

> **本版性质：结论勘误，不是功能升级。** 更正 v1.15.24 中关于 `www.aaawz.cc`「Legado 3.25 规则层无法还原 / 目录名仍不可救」的错误结论。按用户指示，本轮**不做 AAA 书源**（别家已做好），我方 `AAA小说(3A小说网)书源.json` 一行未改。

## 一、被推翻了什么

v1.15.24 依据四份实站 woff2 的**字形轮廓层**取证，把 `www.aaawz.cc` 判为「CJK 基本区恒等 cmap + 会话级字形轮廓替换」站型，进而下了三层结论：

| # | v1.15.24 结论 | v1.15.25 实测 |
|---|---|---|
| 1 | 会话级无限动态字形，静态映射表必失效 | 站点使用**有限 16 套固定字符置换表**轮换；`font.url` 文件名前 12 位即表号 |
| 2 | Legado 3.25 规则层无法自动还原正文 | 规则层 `jsLib` 内置表 + `aaDecode(font.url, 文本)` 逐字查表即可解出通顺正文 |
| 3 | 目录名仍不可救 | 真实 1496 条目录名全部解出，残留乱码特征字符 0 条 |

## 二、错在哪（根因：错归因，按 E16 如实交代）

上一版验的**字形轮廓层**现象都是真的：四份 woff2 轮廓签名全不同、跨会话精确交集 1.18%、家族名随机、换 `reader_guard_id` 后文本零重合。但这属于**渲染层**。

错误在于把「渲染层每会话下发不同字体文件」直接等同于「**字符置换关系**每次会话都变」，并把 `QueryTTF` 三条限制外推成「规则层无解」：

- ① `QueryTTF` 手写 TTF 表目录解析、无 woff2 解码分支；
- ② `glyphToUnicode` 精确 HashMap 匹配、无容差；
- ③ 字形集合可锚在会话级 guard cookie 上，跨会话轮廓变化。

**这三条只封闭 `java.queryTTF` + `java.replaceFont` 这条字体 API 通道，不封闭纯字符串置换解码通道**——后者完全不经过字体 API，是规则层用 `jsLib` 做字符串查表，与字体解析无关。字体文件确实每会话变，但站点同时把「乱码字 ↔ 正确汉字」的映射固定成了 16 套表，字体文件名前 12 位就是表号。

### 一手规范复核（E26 三问）

| 问 | 出处 | 结论 |
|---|---|---|
| ① 官方怎么定义 | `official-help/ruleHelp.md:180-182`、`references-extra/Legado_3.25_书源编写参考.md:87-89` | 只定义 `queryTTF` / `queryBase64TTF` / `replaceFont` 三个字体 API，**无任何官方条文说规则层不能做字符串置换解码** |
| ② 真实书源怎么写 | 知识库 `samples/` 7 份无字体反爬样本；用户提供的别家 AI 书源 | 别家书源是**可跑的真实规则**：`jsLib` 内置 16 套置换表，`ruleContent` / `ruleToc` 均调 `aaDecode` |
| ③ 凭什么推翻 | 本轮四条独立通道（见 §三） | 换语言复算 + 原始 JS 本体 + 两条规则端到端，不是同一次日志的另一种解读 |

**「规则层无法还原」从来不是官方结论，是我方从字体形态自行外推的。** 这是一次典型的「只验了字形、没验字符映射」的方法论漏洞，不是证据造假。

## 三、四条独立通道实测（夹具指纹：站 `www.aaawz.cc`，实站夹具 `real/aaawz/`）

| 通道 | 做法 | 输出 |
|---|---|---|
| A | Python 换语言重写解码，**不执行别家 JS**，只取两张常量表 | `AA_CODES` 6763 字全唯一；16 表长均 6763、都是完全双射、两两不同、同一下标在 16 表给出 16/16 不同字；历史实站抓到的 **5/5** 个字体 key 全命中 16 表；1496 条目录**全量解码失败 0/1496**；`session_text.json` 乱码正文解成《十日终焉》开篇 |
| B | Node 执行别家 AI **原始 `jsLib` 的 `aaDecode` 本体** | 解码前 40 字「驳忠溺狄揶灞推睽肭溪…」→ 解码后 40 字「一个老旧的钨丝灯被黑色的电线悬在屋子中央，闪烁着昏暗的光芒。」与通道 A 一致 |
| C1 | Node 端到端跑 **`ruleContent.content` 规则本体**，用真实乱码正文构造 `result` | 输出「一个老旧的钨丝灯被黑色的电线悬在屋子中央，闪烁着昏暗的光芒。\n\n静谧的气氛犹如墨汁滴入清水…」，判定正确 |
| C2 | Node 端到端跑 **`ruleToc.chapterList` 规则本体**，喂 `ct_log.json` 真实 1496 条响应 | 返回 Array 1496 条；`[0] 第1章 空屋`、`[748] 第749章 皆是蝼蚁`、`[1495] 陈俊南（终）`；残留乱码特征字符 **0/1496** |

16 个表号：`0d7cb51e834e` `2f611e56e070` `60df801f5466` `61a0247a403c` `73789909cb36` `7c80b9292816` `83362f13c4a4` `8591bf955c87` `90a8ffc1781c` `b1fed034a980` `c20d61ba3f3e` `d13b039344cd` `d36af35f8f8e` `de79732fe06d` `eef18399a2a8` `f8b877963c9b`。

## 四、改了什么（只改被指名的那一处）

`scripts/reverse_font.py`，共 8 处精确替换，每处断言唯一命中、替换后打印首尾各 20 字符核对边界：

| # | 位置 | 改前 → 改后 |
|---|---|---|
| 1 | 模块 docstring 站型 B 段 | 「该类【无法自动还原】」→「字体形态 ≠ 字符置换关系，能力字段改 `None`，不下无解禁令」 |
| 2 | `classify_font_obfuscation` docstring | 补 `rule_layer_recoverable` 三态语义说明 |
| 3 | 站型 B 返回块 | `False` → `None`；`note` 重写（适用通道边界 + 实站反证 + 三条取证清单） |
| 4 | `diagnose()` 注释 | 说明 `unrecoverable` 只收「已独立证实不可还原」 |
| 5 | `diagnose()` verdict | 「3.25 规则层无法自动还原」→「字体 API 通道不适用，规则层能力【未判定】，须另查有限置换表」 |
| 6 | 顶层汇总（**连带修假绿**） | `False if unrecoverable else None if not fonts else True` → 三态透传，只有真反推出映射才 `True`。旧写法会把站型 B 的 `None` 错报成 `True` |
| 7 | `_print_report` | 二值 `True/False` → 三态可读文案「可自动反推 / 已证实不可还原 / 未判定(须另取证)」 |
| 8 | `analyze_font` 注释 | 标注能力字段为三态、不再由站型直接推断 |

**未改**：站型三态判据（`CJK_CMAP_MIN_ENTRIES` / `CJK_CMAP_MIN_RATIO` / `IDENTITY_GLYPHNAME_MIN_RATIO`）、`FONT_RE`、`read_font_format`、`infer_unicode_from_glyphname`、`build_mapping`、`generate_replace_regex`、`detect_content_crypto`、`extract_fonts`、`FONT_FILE_SUFFIXES`、`_is_font_file`。**不新增置换表检测能力，不生成任何假映射。**

## 五、判据（改前/改后同一夹具 A/B + 独立复算）

| 项 | 改前 | 改后 | 结果 |
|---|---|---|---|
| A1 四份实站 woff2 | `glyph_shape_cjk_identity` / `False` / verdict「3.25 规则层无法自动还原」 | 站型不变 / 能力 `False→None` / 顶层 `False→None` / verdict「未判定 + 取证清单」 | 4/4 通过 |
| A2 `fontTools` 不 import 本脚本独立复算 | — | `total=6763 / cjk_ratio=1.0 / identity_ratio=1.0 / magic=774f4632(woff2)`，与工具 `obfuscation_evidence` 逐值一致 | 4/4 逐值一致 → 站型判据未被改动 |
| A3 合成 cmap 纯函数真值表 | — | 站型 B / 小字表(100) / 随机字形名 / 非 CJK 码位 / PUA 重定向 / 空 cmap，三组反例防假阳 | 6/6 PASS |
| A4 顶层三态透传专项 | 站型 B 顶层会被算成 `True`（假绿） | 顶层 `None`、`auto_mapping_count=0`、`shape_font_count=1` | 无新假绿 |
| 语法 | — | `py_compile` | PASS |

改前快照与改后输出存 `/root/.codebuddy/backup_20261113_errata_v11525/`；A/B 表与验证脚本存本会话临时区 `errata/`（`patch_reverse_font.py` / `verify_after.py` / `ab_table.json`）。这些证据**未随包**（会话级样本无法固化）。

## 六、误判扩散清单（已逐处更正或勘误标注）

| 载体 | 位置 | 本版处理 |
|---|---|---|
| 技能脚本 | `scripts/reverse_font.py` 第 15、122–133、332–340、355、377 行 | **已更正**（§四） |
| 技能总纲 | `SKILL.md` 第 554–559 行 v1.15.24 CHANGELOG | **加勘误指针**，历史正文保留 |
| 发布说明 | `RELEASE_NOTES_v1.15.24.md` 第 7、11、21、34 行 | **加勘误指针**，历史正文保留 |
| 补充材料 | `新增/字体反爬站型与3.25规则层能力边界.md` 第 17、39、43–50、79、83、92–93 行 | **重写为勘误版**（随本版材料包重发） |
| 补充材料清单 | `README_补充材料清单.md` | 同步更正 |
| 已外发信件 | `致引擎侧_v1.15.24_…_20261112.md` 第 10、22、30、76 行 | 历史件不回改；**新勘误信逐行声明作废** |
| 我方 AAA 书源 | `AAA小说(3A小说网)书源.json` `bookSourceComment` | **按用户指示不做、一行未改**；其注解仍留旧结论，属已知残留 |
| 知识库本体 | `Legado_3.25_书源编写参考.md` §1.5.1（引擎侧 11-13 回执确认已并入 `f91e8b9`） | 勘误信**请引擎侧替换** |

## 七、边界（如实，未拔高证据等级）

- **本版只更正结论层**：工具仍只吃 cmap + 文件头，判不了字符置换关系，故能力字段一律 `None`（未判定），**不是改成 `True`**。要判规则层能否还原，须另查响应体三条：① 乱码是否来自有限套固定置换表；② 表是否随响应下发或可按 `font.url` 索引；③ 是否能在 `jsLib` 内置表并由规则层逐字查表解码。
- **16 套表覆盖性未证**：本地只抓到 5 个字体 key，全部命中 16 表；不能证明站点永远只发这 16 套。别家 `aaDecode` 对无表 key 原样返回乱码，自带降级兜底。
- **搜索／详情层**：本轮端到端只覆盖 `ruleContent` 与 `ruleToc`；`ruleSearch` / `ruleBookInfo` 未用真实响应端到端复跑。`enabledExplore: false`，发现页不启用。
- **harness 近似**：C1/C2 用 `new Function` 包裹以取返回值（末尾 `return arr;` 是 harness 加的），≠ 真机 Rhino 绑定；规则原文末句是裸表达式，与 3.25 表达式上下文一致，但**未做真机复验**（E24）。
- **整体可用性**：别家书源能否在真机 3.25 导入即用，**未做真机复验**。证据等级为**本地实站夹具 L1**，不写「已修复」。
- **上一轮 `js_layer_check.py` 16 个 FAIL** 是默认 HTML 桩不匹配 LZString JSON 响应，属夹具问题，本轮**未**用真实夹具重跑该脚本。
- 三处修复 + 一处勘误的证据等级均为**本地夹具 + 实站字体样本**，未做真机复验；本版**未改动任何书源规则、未升任何书源版本**。

## 八、附件

| 文件 | 说明 |
|---|---|
| `legado-tools_v1.15.25.zip` | 最新版技能包（含本说明与更正后的 `reverse_font.py`） |
| `书源知识库补充材料_20261113_勘误版.zip` | 更正后的补充材料，请替换 11-12 版 |
| `致引擎侧_v1.15.25_aaawz字体结论勘误_20261113.md` | 勘误信，逐行声明旧信作废并请替换知识库 §1.5.1 |
