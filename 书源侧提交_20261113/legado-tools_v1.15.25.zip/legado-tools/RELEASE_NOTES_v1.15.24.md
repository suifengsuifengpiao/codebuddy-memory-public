# legado-booksource-debug v1.15.24 · 发布说明

> ⚠️ **勘误（2026-11-13）**：本说明及本版 `reverse_font.py` 中关于 `www.aaawz.cc`「会话级无限动态字形 / Legado 3.25 规则层无法还原正文 / 目录名仍不可救」的结论**已证伪**，请勿据此写书源或合并进知识库。正确结论与四条独立通道实测见 `RELEASE_NOTES_v1.15.25.md`。本文件作为历史版本记录保留，正文不回改。

对应技能 `legado-booksource-debug` v1.15.24（`SKILL.md` frontmatter / `_meta.json` version / `display_name` / `check_request_layer.py` docstring 四处同步）。

## 这版修三处工具侧判定失真（用户明确授权按流程落地并外发）

起因：排查 `www.aaawz.cc` 目录/正文「看得见却不认识」的乱码时，用 3.25 `classes*.dex` 内 `QueryTTF` + `fontTools` 独立复算确认该站是「CJK 基本区恒等 cmap + 会话级字形轮廓替换」站型，Legado 3.25 规则层无法自动还原。回头复跑工具链，发现 `reverse_font.py` 只认私有区码位，把这份字体报成「可能非加密字体」（假阴性）；整理「知识库缺、我方有」材料时又实测出另外两处。三处均按守则「工具缺陷主动上报 → 用户明确授权后落地」执行，本轮用户已逐项授权「修工具 → 升版本 → 发信说明 → 发最新包 → 整理补充材料 → 请引擎侧同步」。

| 文件 | 缺陷（改前实测） | 修法 |
|---|---|---|
| `scripts/reverse_font.py` | 对 `font_session.woff2`（6763 条 CJK 基本区恒等 cmap）返回 `private_codepoints: []`、`auto_mapping: {}`、无任何站型字段；`diagnose()` 报「检测到自定义字体但未发现私有区编码(可能非加密字体)」 | 新增 `classify_font_obfuscation()` 确定性纯函数分三态（`pua_codepoint_redirect` / `glyph_shape_cjk_identity` / `no_font_obfuscation`）；`analyze_font()` 追加 4 个字段、原字段一个不动；`diagnose()` verdict 显式认站型 B 并标 `rule_layer_recoverable=False`；新增本地字体文件直通通道。**不动 `FONT_RE` / `build_mapping` / `generate_replace_regex` 既有分支** |
| `scripts/js_layer_check.py` | 合法 `loginCheckJs` 片段引用真机绑定 `baseUrl` → `RuntimeError: baseUrl is not defined` / exit=1（假红） | 仅 `cfg.kind === 'loginCheckJs'` 时向 harness `ctx` 注入 `baseUrl`（取 `cfg.url`）；其它作用域不注入，防外溢假绿。`--key` 桩与 18 组内测未改 |
| `precheck_public_push.sh`（技能目录外） | zip 内含令牌明文时，1~5 项全绿 / exit=0（假阴性，最危险） | 新增第 6 项「归档包内脱敏」：解包到临时目录，用与 1~4 项同一套判据补扫；`trap EXIT` 清理；只做文本比对、不执行包内文件。原 1~5 项一行未改 |

> 第三处脚本位于 `/root/.codebuddy/scripts/precheck_public_push.sh`，**不在技能包内**。已作为单独文件随本轮补充材料包发给引擎侧，并说明其安装位置与用法。

## 判据（改前/改后同一夹具 A/B + 独立复算）

| 通道 | 改前 | 改后 |
|---|---|---|
| A1 `reverse_font.py` 对 `font_session.woff2` | `private_codepoints: []`、无站型字段 | `glyph_shape_cjk_identity`、`rule_layer_recoverable=False`、`auto_mapping_count=0`、verdict 明写「规则层无法自动还原」 |
| A1 纯函数真值表 6 组（含 3 组反例） | — | 6/6 PASS；小字表 / 随机字形名 / 非 CJK 码位均不误判为站型 B |
| A1 独立复算（不 import 本脚本，`fontTools` 直读 woff2） | — | `total=6763 / cjk_ratio=1.0 / identity_ratio=1.0`，与工具输出逐值一致 |
| A2 `js_layer_check.py --source` 同一夹具 | `[FAIL] RuntimeError: baseUrl is not defined` / exit=1 | `[PASS] kind=loginCheckJs` / exit=0 |
| A2 反向标本（非 loginCheckJs 作用域用 `baseUrl`） | — | 仍报 `baseUrl is not defined`，证明无全局外溢假绿 |
| A2 `--self-test` / `--key` 桩回归 | 18/18 / 通过 | 18/18 / 通过（既有能力未被破坏） |
| A3 含令牌明文 zip 的门禁 | 四项全绿 / exit=0 | `❌ 检出令牌明文【压缩包内】` / exit=1 |
| A3 干净 zip / 真实 `legado-tools_v1.15.23.zip` | — | 均 exit=0（无假阳、不误伤） |

改前快照（三脚本原文件副本 + `baseline.sha256` + `before_*` 输出）与改后全部输出存 `/root/.codebuddy/backup_20261112_tools_v11524/`，可逐字 diff。

## 边界（如实）

- `classify_font_obfuscation` 是**启发式判据**，只识别站型，不等于证明加密；「是否会话级动态字形」须另取多份同站字体比对轮廓集合，本工具不自动下此结论。站型 B 的 `obfuscation_note` 已把 3.25 规则层三条限制（woff2 无解码分支 / 精确 HashMap 无容差 / 会话动态）写明，但不生成任何假映射。
- `baseUrl` 桩取 `cfg.url`，是 Node V8 近似，≠ 真机 Rhino 绑定值；只消除「变量未定义」这一层假红。
- 门禁第 6 项：不检查包内技能包的版本同步（第 5 项仍只查平铺技能包）；>50MB 包显式告警并跳过（已知边界，防撑爆临时盘）。
- 三处修复的证据等级均为**本地夹具 + 实站字体样本**，未做真机复验；未改动任何书源规则、未升任何书源版本。
- 本版按用户授权外发：发信说明升级原因、随信附最新技能包与补充材料包，请引擎侧同步进书源知识库。知识库本体仍由引擎侧合并，我方不代推。
