#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
请求层闸（第五道闸）· check_request_layer.py
=============================================
用途：在把书源交给宿主（Legado）之前，模拟宿主对 **URL / 请求参数** 的解析，
      抓出「解析层四道闸永远看不到」的错误。

由来（2026-11-02 duomle 真机事故）：
  - exploreUrl 用 JSON 数组格式，却把 ,{"webView":true} 直接塞进 url 字符串未转义
    → 宿主 gson 抛 MalformedJsonException: Unterminated object at line 1 column 74 path $[0].url
    → 发现页整段崩溃，而 validate / test_parse 全绿（它们不碰 URL 字符串）
  - searchUrl 同时写 method:POST 与 webView:true
    → Android WebView 只能 GET，POST body 丢失 → 服务端收不到关键词 → 列表为空
    → 真机日志「获取书籍列表 → 列表为空，按详情页解析」→ 0 本

检查项：
  R1 exploreUrl 语法：以 [ 开头必须为合法 JSON（逐项 title/url）。
     v1.15.15：直接解析失败时按**宿主 gson 宽容度**再解一次（{{...}} 占位 + 字符串内
     \\n/\\r/\\t 转义）——复解通过 = 只是 Python 比 gson 严 → NOTE；仍失败 = 结构真错 → ERROR
  R2 exploreUrl 文本行格式：每行 标题::URL（以 @js: / <js> 开头时为 JS 动态发现，
     本闸不解析 JS，转 NOTE 提示另验——手机小说真机已验证 @js: 形态合法）
  R3 exploreUrl 各项 URL：内嵌选项 ,{...} 二次解析；相对路径在 bookSourceUrl
     非空时由宿主拼接（合法），bookSourceUrl 为空才报 ERROR。
     不含 {{page}} 是**提示级**（分页机会提示，榜单/分类首页本来只有一页），不阻断 --strict
  R4 searchUrl 结构 + method 与 webView 互斥（相对路径同 R3 口径）
  R5 易失地址启发式（路径含 4+ 位数字，需多会话复验）
  R6 GET searchUrl 里的 {{key}} 中文编码提示：GET 的查询串由宿主 AnalyzeUrl
     编码与否取决于写法，若未编码中文关键词可能取空——WARN 提示改
     {{java.encodeURI(key)}} 或实测确认。**不写选项 = 默认 GET，同样适用**
     （v1.15.13 修：此前 R6 嵌在 `if opt:` 内，裸写法漏报）；显式 method:POST 不报
     （POST 关键词在 body，编码路径不同）
  R7 bookSourceUrl 协议与各规则 URL 协议一致性

切分算法（v1.15.13 重写，逐条对 3.25 dex）：
  `<clinit>` paramPattern = "\\s*,\\s*(?=\\{)"；`analyzeUrl()` 在**首次**匹配处切分
  （url=substring(0,start)、选项=substring(end) 交 gson fromJson），无匹配则整串当 url +
  默认 GET；解析失败被 runCatching 吞成 null（宿主按默认选项继续，不崩）。
  exploreUrl 另走一条：paramPattern 无匹配时 seek=0 → **整串都是 url，不切选项**。
  旧版用 rfind(",{") + json.loads(整段后缀)，两头都比宿主严：既误杀 @js:/<js> 尾部 JS，
  也误判数组内 "url" 值里的 \\",{...}\\"（实测：12 本已交付书源里 3 本被误判 ERROR）。

退出码：0 = 无 ERROR（默认口径，WARN 不阻断）；1 = 有 ERROR，或 --strict 下有阻断级 WARN
用法：python3 check_request_layer.py <书源.json> [--strict]
      --strict：WARN 亦视为失败（R6 这类「编码可能有问题」在严格模式下应阻断交付）
      v1.15.13 前 --strict 只写在用法里、无实现分支，传了等于没传
"""
import json
import re
import sys
import os

RED = "\033[31m"
YEL = "\033[33m"
GRN = "\033[32m"
CYN = "\033[36m"
RST = "\033[0m"

# 3.25 AnalyzeUrl.<clinit>：paramPattern = "\\s*,\\s*(?=\\{)"
PARAM_RE = re.compile(r"\s*,\s*(?=\{)")


class Result:
    def __init__(self):
        self.errors = []
        self.warns = []
        self.notes = []

    def err(self, code, msg):
        self.errors.append((code, msg))

    def warn(self, code, msg, blocking=True):
        """blocking=True：--strict 下视为失败（真的会让你交付后出事）。
        blocking=False：提示性（已真机验证可过、只是建议再确认），--strict 不阻断。
        v1.15.14：此前一刀切「WARN 即失败」，导致 duomle 修复版（真机已验证）在 --strict 下也红，
        把「建议实测确认」和「真的会坏」混为一谈。"""
        self.warns.append((code, msg, blocking))

    def note(self, code, msg):
        self.notes.append((code, msg))


def split_options(raw, host="?"):
    """按 **3.25 宿主自己的算法** 把 'url,{...}' 切分（v1.15.13 重写）。

    旧实现用 `rfind(",{")` + `json.loads(整段后缀)`，与本闸要防的误判同源：
    宿主根本不按"最后一个 ,{" 切，也**不会**因为后缀含多余内容就失败。

    3.25 反编译实证（classes3.dex → `io/legado/app/model/analyzeRule/AnalyzeUrl`）：
      · `<clinit>` 的 `paramPattern = Pattern.compile("\\s*,\\s*(?=\\{)")`
      · `analyzeUrl()` 在该 pattern **首次**匹配处切分：url = substring(0, start)，
        选项 = substring(end)，交给 gson `fromJson(..., UrlOption.class)`；无匹配 → 用整个 ruleUrl、默认选项
      · 选项解析失败被 `runCatching` 吞成 null → 宿主按 **默认 GET + 无选项** 继续（不是崩溃）
      · exploreUrl 另走一条：dex 里 `paramPattern.find()` 为假时 seek=0，即**整串都算 url**，
        不做切分 → 数组里 "url" 值内层带 \",{...}\" 不会被宿主当选项
    gson 按"解析完一个完整对象即返回、忽略其后多余内容"工作（java_probe/Probe3 实测），
    所以 `@js:` / `<js>` 尾部 trailing 的 JS 源码不会让宿主失败。

    返回 (url_part, opt_dict|None, err|None)。err 仅在**选项段本身**不是合法 JSON 对象时给出，
    且在 host=explore 时按宿主口径降级为该段整串当 url 的一部分。
    """
    s = raw.strip()
    if host == "explore":
        # 宿主对 exploreUrl 不切选项（dex: paramPattern.find() 为假 → seek=0，整串当 url）
        return s, None, None
    m = PARAM_RE.search(s)
    if not m:
        return s, None, None
    url_part = s[:m.start()].strip()
    opt_part = s[m.end():].strip()
    if not opt_part.startswith("{"):
        return url_part, None, None
    try:
        opt = json.JSONDecoder().raw_decode(opt_part)[0]
        if not isinstance(opt, dict):
            return url_part, None, f"选项不是 JSON 对象：{opt_part[:80]}"
        return url_part, opt, None
    except Exception as e:
        return url_part, None, f"选项 JSON 非法（{e}）：{opt_part[:120]}"


def _escape_ctrl_in_strings(s):
    r"""把 JSON **字符串内部**的裸控制字符转成转义序列（\n \r \t）。

    只处理引号内的字符：结构层的换行/缩进是合法 JSON 空白，一起转义反而会把整串弄坏。
    反斜杠状态要跟着走——`"a\\"` 里第二个引号是字符串结尾，`"a\"b"` 里的引号不是。
    v1.15.15 两步走的第 ② 步：建模宿主 gson 对控制字符的宽容度，而不是笼统放过。
    """
    out = []
    in_str = False
    esc = False
    mapping = {"\n": r"\n", "\r": r"\r", "\t": r"\t"}
    for ch in s:
        if in_str:
            if esc:
                out.append(ch)
                esc = False
                continue
            if ch == "\\":
                out.append(ch)
                esc = True
                continue
            if ch == '"':
                out.append(ch)
                in_str = False
                continue
            out.append(mapping.get(ch, ch))
            continue
        if ch == '"':
            in_str = True
        out.append(ch)
    return "".join(out)


def _r5_volatile(url):
    """易失地址启发式：返回路径里含 4+ 位连续数字的段（已剔除行内选项、已剔 {{page}} 占位）。

    v1.15.15 起抽成函数共用：结构成功路径与「宽容度差异 NOTE」路径调的是**同一套判据**。
    两处各写一份必然漂移——M2.5 的教训正是「一条本该拦的规则，因为走的是另一条分支就消失」。
    v1.15.14：先把行内选项 ,{...} 从路径里剥掉再判——宿主虽不把它当选项解析（explore 口径），
    但它显然不是 URL 路径的一段；不剥会让 {"webWait":3000} 里的 3000 被误判成易失长数字段。
    """
    u = re.sub(r"\s*,\s*\{.*$", "", url, flags=re.S).replace("{{page}}", "")
    return [seg for seg in re.findall(r"[^/]*\d{4,}[^/]*", u) if re.search(r"\d{4,}", seg)]


def _r5_raw_urls(explore):
    """结构没能完整解析时，从 **exploreUrl 原文** 粗提 URL 片段供 R5 使用（v1.15.15 补）。

    为什么合法：R5 判的是「路径里有没有 4+ 位数字段」，这是 URL 文本的局部性质，
    **不依赖 JSON 结构**。此前 NOTE 分支直接 `return`，导致「有控制字符宽容度差异 + 有易失数字段」
    的源两个问题都不报（X5 实证 ERROR=0 WARN=0）——该拦的没拦住，比误报更坏。
    粗提到什么程度：`https?://[^\\s"'\\\\]+` 起手，再按 JSON/JS 结构字符 `[]{}<>()*$!;|` 切一刀，
    把 `\\n"]},{"title":"…` 这类结构残渣切掉。切不干净的残片只是一段「更像 URL 的垃圾」——
    R5 是启发式，垃圾里若恰好有 4+ 位数字会**多报**，不会漏报（双向验见表 A10）。
    抽不到（`@js:` / `<js>` 动态拼 URL）就不判，由调用方在 NOTE 里如实写明。
    """
    out = []
    for m in re.findall(r"https?://[^\s\"'\\]+", explore):
        for piece in re.split(r"[\[\]{}<>()*$!;|]", m):
            # 切完后只有以 http 开头（或含 4+ 位数字）的才是候选，其余是纯残渣
            if piece.startswith("http"):
                out.append(piece)
    return out


def check_explore(explore, res, base=""):
    if not explore:
        res.note("R1", "exploreUrl 为空，跳过发现页检查")
        return

    # @js: / <js> 开头 = JS 动态发现，宿主先 evalJS 再用返回值；本闸不解析 JS，
    # 按文本行/JSON 逐行解析只会刷出成片误报（亲亲小说 15 条全是这类）。
    # 手机小说书源真机已验证 @js: exploreUrl 合法。
    if re.match(r"^\s*(@js:|<js>)", explore):
        res.note("R1", "exploreUrl 为 JS 动态生成（@js:/<js>），本闸不解析 JS；"
                       "JS 语法另用 js_layer_check.py / 真机验证")
        return

    is_json = explore.lstrip().startswith("[")
    items = []

    if is_json:
        try:
            arr = json.loads(explore)
        except Exception as e:
            # 尽量给出列号，对齐宿主 gson 的报错位置
            col = getattr(e, "colno", None)
            pos = f"，约第 {col} 列" if col else ""
            # {{ }} 内嵌多行 JS 时 Python 的 json 会因裸回车报错，而宿主 gson **能过**
            # （八叉书库实证：java_probe/Probe.java → gson [OK] 元素数=15，格 2 实测）。
            # v1.15.14 的处理是「见 Invalid control character 且含 {{ }} → 整段 NOTE 后 return」，
            # 那是一条**顺序敏感短路**：json.loads 停在第一个错误处，裸换行在前时先报控制字符
            # → 直接 return，后面的未转义选项**永远不会被看见**（g10b 实证 ERROR=0 放过）。
            # v1.15.15 改两步走，把「宽容度差异」与「结构真错」分开：
            #   ① {{...}} 占位成 __JS__（宿主先算 JS 再解析，JS 正文不参与 JSON 结构）
            #   ② 字符串内 \n \r \t 转成字面两字符（gson 宽容接受，本闸建模它的宽容度）
            #   ③ 再 json.loads：成功 = 差异只在宽容度 → NOTE；失败 = 结构本身有问题 → ERROR
            # 不按「有没有 {{ }}」分流：{{ }} 只是常见伴随特征，不是判据。
            probe = _escape_ctrl_in_strings(re.sub(r"\{\{.*?\}\}", "__JS__", explore, flags=re.S))
            try:
                arr = json.loads(probe)
            except Exception as e2:
                col2 = getattr(e2, "colno", None)
                pos2 = f"，约第 {col2} 列" if col2 else ""
                res.err("R1", f"exploreUrl 声明为 JSON 数组但解析失败{pos2}：{e2}"
                               f"（按宿主宽容度复解后仍失败；直接解析报：{e}）")
                # 直接解析报的是控制字符错时，它不是缺陷本身（gson 宽容接受），
                # 复解后的结构错才是真错；此时不再复述「双引号提前闭合」定位——同一处缺陷
                # 会被报成三条，且定位片段以裸换行开头、反而读不出位置（g10b 实证）。
                # 直接解析已是结构错（如 duomle v4 的 Expecting ',' delimiter）时保留定位与两条修法。
                if "Invalid control character" not in str(e):
                    m = re.search(r'"[^"]*?,\{"', explore)
                    if m:
                        res.err("R1", f"疑似未转义的内嵌选项（此处双引号提前闭合字符串）：…{explore[max(0,m.start()-40):m.end()+40]}…")
                        res.err("R1", '修法一：内层引号转义为 \\" ；修法二（更稳）：改用文本行格式 标题::URL,{"webView":true}')
                return
            # v1.15.15 补（主灵独立复核抓到的原五项遗漏）：这里**不能直接 return**。
            # 结构复解通过只说明"宽容度差异"，但元素级规则里 R5 判的是 URL 文本局部性质
            # （路径有没有 4+ 位数字段），**不依赖 JSON 结构**，原文就能判。
            # 旧实现一 return，就出现「有控制字符错 + 有易失数字段 → 两个都不报」（X5 实证
            # ERROR=0 WARN=0）——该拦的没拦住。
            # R3 仍跳过：它判的是"这条分类含不含 {{page}}"，按条目看的，原文粗提会把相邻条目
            # 粘成一段、判不准；**必须在 NOTE 里写明跳过的是 R3，看见的人才知道哪些查过**。
            raw_urls = _r5_raw_urls(explore)
            hits = [(u, _r5_volatile(u)) for u in raw_urls]
            hits = [(u, sg) for u, sg in hits if sg]
            if not raw_urls:
                r5_txt = "R5 按原文抽取补判：未抽到 URL 片段（@js:/<js> 动态拼 URL 时属正常），此路径下 R5 无结论"
            elif hits:
                r5_txt = "R5 按原文抽取补判：命中 " + "；".join(
                    f"…{u[-60:]} → '{'/'.join(sg)}'" for u, sg in hits)
            else:
                r5_txt = f"R5 按原文抽取补判：抽到 {len(raw_urls)} 段 URL 均无 4+ 位长数字段"
            for u, segs in hits:
                for seg in segs:
                    res.warn("R5", f"[原文抽取] 路径含长数字段 '{seg}'（片段 …{u[-70:]}），疑似易失地址；"
                                    f"须用 3 个独立会话复验是否稳定。"
                                    f"注意：JSON 结构未能完整解析，本判定基于原文抽取，条目归属未知")
            res.note("R1", "exploreUrl 为 JSON 数组：Python json 直接解析失败（"
                           + str(e) + "），但按宿主 gson 宽容度复解通过"
                           "（{{...}} 占位 + 字符串内控制字符转义）→ 判为解析器宽容度差异；"
                           "**R3 因结构未解析跳过**（分页判据按分类条目看，原文抽取不可靠；未检查 ≠ 已通过）；"
                           + r5_txt +
                           "；JS 语法另用 js_layer_check.py / 真机验证")
            return
            for u, segs in hits:
                for seg in segs:
                    res.warn("R5", f"[原文抽取] 路径含长数字段 '{seg}'（片段 …{u[-70:]}），疑似易失地址；"
                                    f"须用 3 个独立会话复验是否稳定。"
                                    f"注意：JSON 结构未能完整解析，本判定基于原文抽取，条目归属未知")
            res.note("R1", "exploreUrl 为 JSON 数组：Python json 直接解析失败（"
                           + str(e) + "），但按宿主 gson 宽容度复解通过"
                           "（{{...}} 占位 + 字符串内控制字符转义）→ 判为解析器宽容度差异；"
                           "**R3 因结构未解析跳过**（分页判据按分类条目看，原文抽取不可靠）；"
                           + r5_txt +
                           "；JS 语法另用 js_layer_check.py / 真机验证")
            return
        if not isinstance(arr, list) or not arr:
            res.err("R1", "exploreUrl JSON 不是非空数组")
            return
        for i, it in enumerate(arr):
            if not isinstance(it, dict):
                res.err("R1", f"第 {i} 项不是对象：{it!r}")
                continue
            if "title" not in it or "url" not in it:
                res.err("R1", f"第 {i} 项缺 title/url：{list(it.keys())}")
                continue
            items.append((it["title"], str(it["url"]), f"JSON[{i}]"))
    else:
        for ln, line in enumerate(explore.splitlines(), 1):
            line = line.strip()
            if not line:
                continue
            if "::" not in line:
                res.err("R2", f"第 {ln} 行缺 '标题::URL' 分隔符：{line[:80]}")
                continue
            title, url = line.split("::", 1)
            items.append((title.strip(), url.strip(), f"行{ln}"))

    if not items:
        res.err("R1", "exploreUrl 未解析出任何分类项")
        return

    res.note("R1", f"exploreUrl 格式={'JSON数组' if is_json else '文本行'}，共 {len(items)} 项")

    for title, raw, where in items:
        url, opt, oerr = split_options(raw, host="explore")
        if oerr:
            res.err("R3", f"[{where}]「{title}」内嵌选项非法：{oerr}")
            continue
        if not re.match(r"^https?://", url):
            # 相对路径：宿主 AnalyzeUrl 以 bookSourceUrl 为基拼接（workflow-detail.md 既有结论；
            # 来读读 2026-10-31 真机调通、读书斋已交付，均为相对 exploreUrl）。
            # bookSourceUrl 为空时无处可拼 → 才是 ERROR。
            if base:
                res.note("R3", f"[{where}]「{title}」为相对路径，宿主以 bookSourceUrl({base}) 拼接")
            else:
                res.err("R3", f"[{where}]「{title}」URL 不以 http(s):// 开头且 bookSourceUrl 为空，宿主无处拼接基址：{url[:80]}")
        if "{{page}}" not in url:
            # v1.15.15：降为提示级。原文是「**可能**永远只取第 1 页」——推测；且实测红的全是
            # 榜单页 / 分类首页（读书斋 10 条分类首页、百草露 2 条榜、yqkxs 7 条榜），本来只有一页。
            # 宿主对 exploreUrl 的翻页只认 {{page}} 模板，不含即不翻页——这是**机制事实**；
            # 但「该分类有没有第二页」静态判不了，按缺陷判会误伤，故只提示、不阻断 --strict。
            res.warn("R3", f"[{where}]「{title}」URL 不含 {{{{page}}}}：分页机会提示（榜单/分类首页本来只有一页，"
                           f"是否缺陷取决于该分类有无第二页，静态判断不了）", blocking=False)
        # 易失地址启发式（判据见 _r5_volatile，与 NOTE 路径共用同一函数，不各写一份）
        for seg in _r5_volatile(url):
            res.warn("R5", f"[{where}]「{title}」路径含长数字段 '{seg}'，疑似易失地址；须用 3 个独立会话复验是否稳定")


def check_search(search, res, base=""):
    if not search:
        res.note("R4", "searchUrl 为空，跳过搜索检查")
        return
    url, opt, oerr = split_options(search)
    if oerr:
        res.err("R4", f"searchUrl 选项 JSON 非法：{oerr}")
        return
    if not re.match(r"^https?://", url):
        # 与 R3 同口径：相对路径 + bookSourceUrl 非空 = 宿主拼接（来读读真机调通同形态）
        if base:
            res.note("R4", f"searchUrl 为相对路径，宿主以 bookSourceUrl({base}) 拼接")
        else:
            res.err("R4", f"searchUrl 不以 http(s):// 开头且 bookSourceUrl 为空：{url[:80]}")
    # 关键词载体（v1.15.13 精修两处漏报，均为实测）：
    #   ① `"{{key}}" not in url` 会把 R6 自己建议的处方 {{java.encodeURI(key)}} 判成 ERROR ——
    #      处方执行完反而新增一条红，见 `references/maintenance.md` 与 CHANGELOG；
    #   ② `@js:` / `<js>` 动态 URL 里关键词常以 `+key+` 拼接、或整串由 JS 返回，原逻辑只认字面
    #      `{{key}}` → 已交付的 八叉书库 / 手机小说 / luyouxs 三本被误判 ERROR（它们是 JS 返回形态）。
    # 载体判定：整个 searchUrl 原文（含 JS 源码）或 body 里出现 key 变量或 {{key}} 即算。
    # 宿主在 analyzeUrl 之前就把整个串当 URL 处理，故原文（含 JS 尾巴）要一起看。
    # 注意不能用 `search` 全文：`cookie` / `searchkey` 里的 "key" 会被子串匹配骗过
    # （正则已带词边界，但关键词本身可能只出现在 JS 尾巴里，故只取 url 段 + body，不做全文）。
    key_src = url + "\n" + str((opt or {}).get("body", ""))
    KEY_VAR_RE = re.compile(r"(?<![A-Za-z0-9_$])key(?![A-Za-z0-9_$])")
    if "{{key}}" not in key_src and not KEY_VAR_RE.search(key_src):
        res.err("R4", "searchUrl 与 body 里都找不到 key（{{key}} / +key+ / {{java.encodeURI(key)}}），搜索词无处可去")
    # v1.15.13：无选项 = 默认 GET，与显式 method:GET 同口径。
    # 旧写法把 R6 整段嵌在 `if opt:` 内，裸 searchUrl（不写选项）走 else 只打 NOTE
    # → 「GET URL 含 {{key}} 未编码」这条最常命中的提示，恰恰在最常见的写法上不响。
    if opt:
        method = str(opt.get("method", "GET")).upper()
        webview = bool(opt.get("webView"))
        if method == "POST" and webview:
            res.err("R4", "method=POST 与 webView=true 互斥：Android WebView 只能 GET，POST body 会丢失，服务端收不到关键词（duomle 真机事故根因）")
        res.note("R4", f"searchUrl method={method}, webView={webview}")
    else:
        method = "GET"
        res.note("R4", "searchUrl 无选项 → 按默认 method=GET, webView=False 检查")
    # method 显式 POST 不报：关键词走 body，编码由 body 路径决定，与 URL 查询串无关。
    # 已经显式编码的写法（{{java.encodeURI(key)}} 等）不再提示——它是本条 WARN 的处方，
    # 处方执行完还响 = 永远消不掉的红灯（v1.15.13 实测：照建议改完反而先被 R4 判 ERROR）。
    if method == "GET" and "{{key}}" in url:
        res.warn("R6", "GET URL 含 {{key}}：若宿主未自动编码，中文关键词可能未编码；建议 {{java.encodeURI(key)}} 或实测确认",
                     blocking=False)   # v1.15.14：宿主 AnalyzeUrl 默认会对 {{key}} 做 URL 编码（多本已交付源真机可搜），
                     # 属"建议再确认"而非"交付后会坏"；duomle 修复版真机通过却因此被判 strict 失败，是误伤。


def check_consistency(book, res):
    base = book.get("bookSourceUrl", "")
    if not base:
        res.err("R7", "bookSourceUrl 为空")
        return
    b_scheme = "https" if base.startswith("https://") else "http" if base.startswith("http://") else "?"
    if b_scheme == "?":
        res.err("R7", f"bookSourceUrl 协议异常：{base[:60]}")
    for field in ("searchUrl", "exploreUrl"):
        v = book.get(field) or ""
        schemes = set(re.findall(r"https?://", v))
        if schemes and b_scheme != "?":
            other = schemes - {b_scheme + "://"}
            if other:
                res.warn("R7", f"{field} 混用协议 {sorted(schemes)}，bookSourceUrl={b_scheme}；https 若证书不匹配会整段失败")


def main():
    # v1.15.13：--strict 从「只写在用法里」改为真实现。旧版两处用法文本都写了它，
    # 却没有一个分支读它 —— 传了等于没传，WARN 在严格模式下静默放行。
    strict = "--strict" in sys.argv[1:]
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print("用法: python3 check_request_layer.py <书源.json> [--strict]")
        sys.exit(2)
    path = args[0]
    if not os.path.exists(path):
        print(f"{RED}文件不存在：{path}{RST}")
        sys.exit(2)

    data = json.load(open(path, encoding="utf-8"))
    books = data if isinstance(data, list) else [data]

    total_err = 0
    total_warn = 0
    total_warn_info = 0
    for bi, book in enumerate(books):
        name = book.get("bookSourceName", f"#{bi}")
        print(f"\n{CYN}{'='*64}{RST}")
        print(f"{CYN}请求层闸 · {name}{RST}")
        print(f"{CYN}{'='*64}{RST}")
        res = Result()
        base = book.get("bookSourceUrl", "")
        check_explore(book.get("exploreUrl"), res, base)
        check_search(book.get("searchUrl"), res, base)
        check_consistency(book, res)

        for c, m in res.errors:
            print(f"{RED}[ERROR]{RST} {c} {m}")
        for c, m, blocking in res.warns:
            # v1.15.15：标签对称。`[WARN ]` 的尾空格看着像排版，实际让「阻断/提示」在肉眼上
            # 无法对齐分辨（一个 6 字、一个 8 字）；改成两个都是 8 字宽的中文标签。
            tag = "[WARN·阻断]" if blocking else "[WARN·提示]"
            print(f"{YEL}{tag}{RST} {c} {m}")
        for c, m in res.notes:
            print(f"{GRN}[NOTE ]{RST} {c} {m}")

        n_block = sum(1 for w in res.warns if w[2])
        n_info = len(res.warns) - n_block
        print(f"\n小计：ERROR={len(res.errors)}  WARN={len(res.warns)}"
              f"（阻断 {n_block} / 提示 {n_info}）  NOTE={len(res.notes)}")
        total_err += len(res.errors)
        total_warn += n_block
        total_warn_info += n_info

    print(f"\n{'='*64}")
    if total_err:
        print(f"{RED}结论：请求层不通过，ERROR={total_err}——这些错误 validate / test_parse 都查不出来，必须修完再交付。{RST}")
        sys.exit(1)
    if strict and total_warn:
        print(f"{RED}结论：--strict: 阻断级 WARN 视为失败，请求层不通过（阻断 WARN={total_warn}）。"
              f"这些是「交付后真会坏」的隐患（分页失效/地址易失/证书不匹配），必须处理。{RST}")
        sys.exit(1)
    if total_warn_info:
        print(f"{YEL}提示：有 {total_warn_info} 条提示级 WARN（不阻断 --strict）——建议实测确认，但不影响交付判定。{RST}")
    # 通过时不复述 --strict 口径：回退实验里那句话会让「分支被短路」的日志与正常日志只差 exit code，
    # 从输出看不出"本该失败"（v1.15.13 实测）。口径只在失败分支说一次。
    print(f"{GRN}结论：请求层通过（ERROR=0）。注意：本闸只验「宿主能否解析并发出请求」，不验站点是否真返回预期内容，后者仍需真实页/真机证据。{RST}")
    sys.exit(0)


if __name__ == "__main__":
    main()
