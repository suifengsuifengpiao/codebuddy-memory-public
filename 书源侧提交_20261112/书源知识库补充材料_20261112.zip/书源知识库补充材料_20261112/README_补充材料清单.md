# 书源知识库补充材料清单 · 2026-11-12

> 来源：书源侧按「知识库没有、我方有、且对写书源有帮助」做的差集。以 Gitee `legado-booksource-knowledge` 本体 `de8a33e`（2026-11-11 22:13:12 +0800）为对比基准。
> **书源侧不代推知识库本体**；本包只是提交材料，合并范围由引擎侧判断。
> 包内不含令牌明文、`SOUL.md` / `MEMORY.md` 记忆层文件、沙箱 hostname / 会话 UUID，已过 `precheck_public_push.sh` 六项门禁（含新增的第 6 项「归档包内脱敏」）。

## 一、目录与落点建议

| 目录 | 内容 | 建议落点 | 证据等级 |
|---|---|---|---|
| `新增/` | `字体反爬站型与3.25规则层能力边界.md` | 合并进 `references-extra/Legado_3.25_书源编写参考.md` §1.5（现只列 API、缺能力边界） | 判据 L1（3.25 dex + 抽取 `QueryTTF.java` + fontTools 独立复算）；站型实测数字属「本地实测、样本未随包」，见文内 §4 说明 |
| `references_独有/` | 8 项：知识库 `references-extra/` 完全没有 | 拷入 `references-extra/` | 3.25 dex 实证（L1）/ 工作流与调试经验（L2 转述） |
| `references_同名内容更新/` | 4 份：同名但内容不同，技能侧为含 3.25 实证的更新版 | 逐份 diff 后合并进 `references-extra/` 同名文件 | 同上；**不是让引擎侧直接覆盖**，请以 diff 为准 |
| `tools_脚本级/` | `precheck_public_push.sh`（v1.15.24 修复版） | 知识库 `tools/` 或引擎侧脚本目录 | 本地夹具 A/B（6 组，含反向标本） |

## 二、`references_独有/` 逐份用途

| 文件 | 对写书源的帮助 |
|---|---|
| `apk-method-inventory.md` | 3.25 反编译方法清单：判断某个字段 / API 在这个构建里到底有没有，避免凭直觉猜源码 |
| `device-diagnosis.md` | 无电脑时用诊断探针书源定位解析失败，真机日志拿不到时的替代通道 |
| `device-log-cheatsheet.md` | 真机日志关键字速查（目录总数 / 正文 URL / 取空归因） |
| `field-availability.md` | 字段可用性矩阵：哪些字段在哪些规则组里有效，避免写死字段 |
| `maintenance.md` | 工具链维护与 schema 登记约定，供引擎侧维护 `tools/` 时对照 |
| `setup-guide.md` | 校验环境搭建（`jsoup_eval` / Node / fontTools 依赖） |
| `workflow-detail.md` | 「先取证 → 分析 → 生成 → 验证 → 调试」的细化步骤与踩坑点 |
| `evidence/`（4 文件） | 一手反编译证据：`AnalyzeByJSoup.kt`、`AnalyzeRule-SourceRule.java`（`##` 四段切分完整反编译）、`jsoup-from-apk.jar`（真 Jsoup 引擎，供 `test_parse.py` 用）、`README.md` 索引 |

## 三、`references_同名内容更新/` 判定依据

以 `diff -rq <技能 references/> <知识库 references-extra/>` 实测：同名且内容一致的只有 `legend-js-api.md`、`site-patterns.md`（**不在本包**）；以下 4 份内容不同，技能侧版本含后续 3.25 实证与 `##` 切段、URL 行内选项等更新，故一并提交供 diff：

- `apk-3.25-verified-facts.md`
- `booksource-schema.md`
- `parse-paths.md`
- `pitfalls.md`

## 四、本轮工具升级需同步的脚本（**在技能包里，不在本材料包**）

升 v1.15.24 时，技能包内 3 个脚本与知识库 `tools/` 同名文件产生 hash 漂移，请引擎侧同步：

| 脚本 | 变更 |
|---|---|
| `scripts/reverse_font.py` | 新增字体站型分型（修站型 B 假阴性）、本地字体文件直通通道 |
| `scripts/js_layer_check.py` | `loginCheckJs` 作用域补 `baseUrl` 桩（修假红） |
| `scripts/check_request_layer.py` | 仅 docstring 版本号 → v1.15.24 |

`self_audit.py` / `verify_booksource.py` 等其余同名脚本 hash 仍一致，不需同步。

> 另：`precheck_public_push.sh` 位于 `/root/.codebuddy/scripts/`，**不在技能包内**（脚本级门禁，历史约定不随技能包分发），故单独放 `tools_脚本级/`。本轮给它加了第 6 项「归档包内脱敏」。

## 五、门禁与复算

- 本包与技能包推送前均已过 `precheck_public_push.sh`（六项：令牌明文 / 凭证模式 / 记忆层文件 / 沙箱标识 / 版本同步 / 归档包内脱敏）。第 6 项是本轮新增，防 `.zip` 内的令牌明文被 `grep -I` 整包跳过。
- 字体站型判据的自包含复算片段见 `新增/字体反爬站型与3.25规则层能力边界.md` §4，只需 `fontTools` 与两份同站不同会话的 woff2。
- 三处工具修复的改前/改后 A/B、纯函数真值表 6/6、独立复算、反向标本证据存书源侧会话沙箱 `/root/.codebuddy/backup_20261112_tools_v11524/`，未随包；技能包内 `RELEASE_NOTES_v1.15.24.md` 已逐项记录判据与边界。
