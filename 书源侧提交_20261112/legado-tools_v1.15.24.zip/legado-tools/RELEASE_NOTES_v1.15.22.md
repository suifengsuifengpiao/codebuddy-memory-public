# legado-booksource-debug v1.15.22 · 发布说明

对应技能 `legado-booksource-debug` v1.15.22（`SKILL.md` frontmatter / `_meta.json` version / `display_name` / `check_request_layer.py` docstring 四处同步）。

## 这版只为一件事：`##` 切段完整 dex 落盘

书源侧主理将原列为「书源侧下一版待办」的 `##` 切段完整 jadx 反编译证据落盘**移交引擎侧（我方）直接落地**（合并权在引擎侧，书源侧不越权代推，见往来件库 `致引擎侧_dex落盘改由引擎侧落地_20261103.md`）。本轮把 `AnalyzeRule$SourceRule.makeUpRule` 的 `##` 四段切分机制（`kotlin.text.u.H0(rule, {"##"}, 0, 6)`：第0段=规则主体 / 第1段=replaceRegex / 第2段=replacement / 第3段存在即 replaceFirst）完整反编译落盘到 `references/evidence/AnalyzeRule-SourceRule.java`。

| 文件 | 改动 |
|---|---|
| `references/evidence/AnalyzeRule-SourceRule.java`（新增，约 13 KB） | legado_app_3.25.apk（md5 `7c5ab9dfa751f58b8ef0220ae001d619`，vcode 15604）经 jadx 1.5.0 反编译 `io.legado.app.model.analyzeRule.AnalyzeRule$SourceRule`（classes3.dex）所得，含 `makeUpRule`（第 1844 行 `H0` 按 `##` 切四段）/ `splitRegex` / `splitSourceRule` 完整内部类 |
| `references/evidence/README.md` | 补 `AnalyzeRule-SourceRule.java` 条目（证明什么 / 怎么核对 / 出处 / 引用约定） |
| `parse-paths.md` / `pitfalls.md` / `field-availability.md` / `booksource-schema.md` / `workflow-detail.md` | `##` / `##$##` 相关论断追加指向 `references/evidence/AnalyzeRule-SourceRule.java` 的完整反编译引用 |
| 版本四处 | `SKILL.md` frontmatter / `_meta.json` version / `display_name` / `check_request_layer.py` docstring |

## 判据（三道自带自检全绿）

| 门禁 | 结果 |
|---|---|
| 版本同步 `check_version_sync` | exit=0（三处一致 1.15.22） |
| `self_audit` 六项 | 全过（含证据随包检查：新证据文件被引用且真实存在） |
| `evals` 评测 | 96/96 |

未改动任何解析 / 校验器逻辑，纯证据补强，行为零变化。

## 边界（如实）

- dex 落盘为完整反编译代码物证，未做真机复跑 `##` 切段行为（该行为已由更早版本实证）。
- 知识库 `tools/check_request_layer.py` docstring 版本号已同步至 1.15.22（与技能包 `scripts/` 1:1）。
