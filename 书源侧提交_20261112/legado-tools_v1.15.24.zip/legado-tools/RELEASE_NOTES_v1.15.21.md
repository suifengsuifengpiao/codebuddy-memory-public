# legado-tools v1.15.21 · 发布说明

对应技能 `legado-booksource-debug` v1.15.21（`SKILL.md` / `_meta.json` / `check_request_layer.py` 三处同步）。

## 这版只为一件事故：知识库那边跑不了自检

引擎侧把 `tools/` 的脚本**平铺在根目录**（与技能 `scripts/` 1:1），而 `evals/run_evals.py`
硬编码 `scripts/` 定位校验器、`self_audit.py` 硬编码「上一级是技能根」。结果是：**知识库那份工具链
自检与评测都跑不起来**——第二通道形同不存在，别人只能相信技能包里的那份 96/96。

| 文件 | 改动 |
|---|---|
| `evals/run_evals.py` | `_resolve_skill_dir()` + `_sdir()`：两布局自动定位；证据复跑把「执行命令」与「比对命令」拆开 |
| `evals/jsoup_realdevice_equiv.py` | `import test_parse` 追加上一级 `sys.path`（平铺时同级） |
| `scripts/self_audit.py` | `_resolve_root()` 判根；`SCRIPTS_DIR` 单列；证据存在性检查对 `scripts/<名字>` 兜底查根目录 |

## 判据（两布局同跑，不是"应该没问题"）

| 布局 | 修前 | 修后 |
|---|---|---|
| 技能包 `<root>/scripts/` | 96/96 / 六项过 | 96/96 / 六项过 |
| 知识库平铺 `<root>/*.py` | **92/96**，`self_audit` **ERROR=27** | **96/96**，`self_audit` 六项过 |

那 27 条全是「证据文件未随包」的假报——文档写 `scripts/x.py`，文件就在同级，工具只认前缀。

## 怎么复算

```bash
# 技能包布局
python3 scripts/self_audit.py && python3 evals/run_evals.py

# 平铺布局（模拟知识库 tools/）：把 *.py、evals/、samples/、references/、SKILL.md、
# _meta.json、skill-dependencies.json 放同一目录，然后
python3 evals/run_evals.py     # 期望 96/96
python3 self_audit.py          # 期望六项通过
```

## 边界

- 只按引擎侧描述与 `tools/` 文件清单**模拟**布局，没有拉到知识库 `tools/` 目录实跑；若那边另有
  `lint/` 等本地特化文件参与，未纳入模拟。
- 未改任何解析/校验逻辑，改动全在路径定位与命令拼装，故 96/96 的语义与 v1.15.20 一致。
