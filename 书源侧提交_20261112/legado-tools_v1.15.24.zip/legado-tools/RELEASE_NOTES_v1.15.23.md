# legado-booksource-debug v1.15.23 · 发布说明

对应技能 `legado-booksource-debug` v1.15.23（`SKILL.md` frontmatter / `_meta.json` version / `display_name` / `check_request_layer.py` docstring 四处同步）。

## 这版修三处工具侧缺陷（用户实测发现并明确授权；第三处为同版补修，未升版本号）

制作 `978小说网书源.json` 交付时发现：`verify_booksource.py` 把「中性 SKIP + 本地不执行的 JS 规则」判成 `PASS`（假绿），`js_layer_check.py` 的 Node 桩缺搜索上下文变量 `key`、对合法 `searchUrl <js>` 报 `key is not defined`（假红）。按项目守则「工具缺陷主动上报 → 只报告不动手 → 用户明确授权后落地」执行。

升版本当时还发现第三处：`self_audit.py` 的 CLI 一致性检查把「引用其它脚本真实参数」的说明文字误判成本脚本「声明了不认的参数」。当时只改文档措辞规避、没修判据；用户指出「发现改进点不一起修」后，按授权做**同版补修**（版本号仍 1.15.23，发布包重打同名、逐文件同步）。

| 文件 | 改动 |
|---|---|
| `scripts/verify_booksource.py` | 汇总段改四态（`PASS`/`PARTIAL`/`UNKNOWN`/`FAIL`）+ 覆盖度维度；退出码 `0/1/2/3`；新增 `_collect_js_fields()` 结构化统计 JS 字段；修正模板化归因；修 `tproc` 超时未定义崩栈隐患。**只改汇总段与 docstring，不动抓取逻辑** |
| `scripts/js_layer_check.py` | 注入 `--key` 桩通道（cfg / CLI / harness ctx / `_is_search_scope`），仅顶层 `searchUrl`/`exploreUrl` 作用域注入，子规则不注入；`--self-test` 不注入 |
| `scripts/self_audit.py`（同版补修） | `check_cli_args` 差集判据收窄：参数若属于「其它脚本 impl 的并集」→ 判为跨脚本引用语境、降 `[NOTE]` 不报 `[ERROR]`；谁都不认的仍报 `[ERROR]`。并集排除 `self_audit.py` 自身（其 docstring 示例串不是真实 CLI 契约，混进并集会把反向标本放绿）。`main` 增 `notices` 接线让过滤可见、不静默吞。**只改这一个函数 + 一行接线，不动 `_doc_args` 窗口** |
| `SKILL.md` / `_meta.json` / `check_request_layer.py` | 版本四处同步 + CHANGELOG 末条；`SKILL.md` CHANGELOG 在既有 1.15.23 条目内追加第 ③ 项补记（不新增版本条目，避免 3b 漂移） |
| 本文件 | 新增发布说明 |

## 判据（改前/改后逐项对照，同一书源 `978小说网书源.json`）

| 门禁 | 改前 | 改后 |
|---|---|---|
| `verify_booksource.py --impersonate chrome` | `PASS` / exit=0（假绿） | **`PARTIAL` / exit=2**（1/5 区域、9 个 JS 字段本地未验、4 区域 SKIP） |
| `js_layer_check.py --source` | 8 PASS + 1 FAIL（`key is not defined`） / exit=1 | **9/9 PASS** / exit=0 |
| 四态真值表（Node 独立复算） | — | 7/7，四态与四个退出码全可达且互斥 |
| `UNKNOWN` 态实站实跑 | — | 全入口不可达零样本 → `UNKNOWN` / exit=3 |
| 反向标本（子规则误用 `key`） | — | 仍 `FAIL`，证明无外溢假绿 |
| `--self-test` 内置回归 | 18/18 | 18/18 |
| 版本同步 `check_version_sync` | exit=0 | exit=0（三处一致 1.15.23） |
| `self_audit` 六项 | 全过 | 全过 |
| `evals` 评测 | 96/96 | 96/96 |

### 第三处（同版补修）判据：改前/改后 A/B（同一夹具）

| 通道 | 改前 | 改后 |
|---|---|---|
| 函数级 A/B（注入「`--keyword` 跨脚本引用 + 凭空假参数」同一夹具） | 两条都报 `ERROR`（`--keyword` 假红复现） | `--keyword` 降 `[NOTE]`，假参数仍 `[ERROR]`（真缺陷不放绿） |
| Node 换语言独立复算（7 组真值表，含自指陷阱） | — | 7/7 PASS |
| `--self-test` 反向标本 | 7/7 全抓 | 7/7 全抓（`--no-such-flag` 未被放绿） |
| `self_audit` 六项 / `evals` | 全过 / 96/96 | 全过 / 96/96 |

> 说明：在**当前真实技能**上改前/改后 `self_audit` 都全绿——因为上一轮已把触发假红的那句措辞改掉，差别只体现在**主动注入跨脚本引用语境的夹具**上，不包装成「改前 ERROR=1」。自指陷阱已实测排除：`others_impl` 含 `--keyword`、不含 `--no-such-flag`。

前两处改前输出与快照存 `/root/.codebuddy/backup_20261111_tools_v11523/`（`before_*.txt` / `*.before` / `baseline.sha256`），改后输出 `after_*.txt`；第三处补修快照存 `/root/.codebuddy/backup_20261111_selfaudit_fix/`，均可逐字 diff。

## 边界（如实）

- 本版改的是**工具判定口径**：`verify` 的 `PARTIAL`/`UNKNOWN` 会改变所有含 JS 规则或抓取不全书源的既有闭环结论（旧版一律 `PASS`）——这是修复目标本身，不是回归。
- `--key` 桩是 Node V8 近似，≠ 真机 Rhino；只消除「变量未定义」这一层假红，不证明真机 `key` 绑定值与之完全相同。
- 未改动任何书源规则；未升任何书源版本；**未外发任何包或信**（外发须另行单独授权）。
- `verify_booksource.py` 的 `PASS` 现在只在「5 区域全有样本且无 JS 本地未验字段」时成立；含 `<js>` 规则的书源基本都会落到 `PARTIAL`，须另用独立 JS 通道（如 `js_layer_check.py` 或 Node 直 eval）与真机补全。
- 第三处判据是**收窄**：只放行「参数确实被本技能其它脚本真实认领」这一种语境；文档写了任何脚本都不认的参数仍照旧报错。被判为引用的参数以 `[NOTE]` 显式列出，不静默吞掉。`_doc_args` 的同行窗口未改（作者实测调过），判据靠「全局 impl 并集」识别引用，不做语义猜测——「宁可漏、不可吵」的取舍仍在。
- 同版补修**未升版本号**：`SKILL.md` frontmatter / `_meta.json` / `display_name` / `check_request_layer.py` docstring 四处仍 1.15.23；发布包重打同名 `legado-tools_v1.15.23.zip`，包内 `self_audit.py` / `SKILL.md` / `RELEASE_NOTES_v1.15.23.md` 与技能目录逐文件同步。
