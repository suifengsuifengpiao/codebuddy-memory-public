# legado-tools v1.15.20 · 发布说明

对应技能 `legado-booksource-debug` v1.15.20（`SKILL.md` / `_meta.json` 同步）。
本包为完整技能树，解包后可在包根目录直接自检，不依赖开发目录。

## 这版改了什么

1. `scripts/validate_booksource.py`：发现页 `ruleExplore` 为空对象/缺失时，回退 `ruleSearch` 的列表规则（3.25 语义）。
   旧版对「`ruleExplore:{}` + exploreUrl 多入口」每入口报一条 `缺字段: bookList/name/bookUrl`。
2. `scripts/verify_booksource.py`：`first_link_from_list` 把 `//x`、`/x` 改写为 `.//x`、`./x`（Legado 语义是挂列表首节点求值，lxml 的 `//` 从文档根重搜会取到 logo/导航）。
3. `scripts/verify_booksource.py`：`first_match` 新增 JSOUP 求值兜底（复用 `test_parse.eval_rule_jsoup`），仅对非 XPath 形态生效；XPath 取空仍老实报 MISS。
4. `scripts/test_parse.py`：`@css:` 前缀改为大小写不敏感（对齐 `AnalyzeByJSoup.kt:484` 的 `startsWith("@CSS:", true)`）。

## 怎么复算

```bash
# 1) 包内自站（须 exit=0）
python3 scripts/self_audit.py
python3 scripts/check_version_sync.py

# 2) 全量回归（须 96/96）
python3 evals/run_evals.py

# 3) 发现页假报对照（ERROR 18→0）
python3 scripts/validate_booksource.py <ruleExplore为空的源>.json

# 4) 详情链路对照（bookinfo 应从站点首页变为 /book/<id>/）
python3 scripts/verify_booksource.py <书源>.json --impersonate chrome
```

## 边界

- `##$##替换` 在 `test_parse` 内按「整串置为替换串」实现，属历史假设，本轮未在 3.25 dex 复验；
  若真机实为「行尾锚点插入」，则 tocUrl 一类规则会差一段，需单独取证后再定，本版未改。
- `first_match` 的 JSOUP 兜底只在 lxml 能建 DOM 时启用；解析层不可用时仍按原逻辑 MISS。
- 本包不含 knowledge 仓库的 `lint/` 工具（v1.14.x 时代的独立资产），技能自身脚本已在 `scripts/`。
